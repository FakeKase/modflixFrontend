import React, { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom'
import './App.css'
import LoginPage from './LoginPage/LoginPage.jsx'
import LandingPage from './LandingPage/LandingPage.jsx'
import ProductPage from './Pages/ProductPage.jsx'
import ProductEditPage from './Pages/EditPage/ProductEditPage.jsx'
import CastEditPage from './Pages/EditPage/CastEditPage.jsx'
import CustomerPage from './Pages/CustomerPage.jsx'
import CastPage from './Pages/CastPage.jsx'
import Background from './Background/Background.jsx'
import mockProfilePic from './assets/rigbyMockProfilePic.png'
import AdminProfilePage from './Pages/AdminProfilePage.jsx'
import ManagementDashboard from './components/ManagementDashboard.jsx'
import Signup from './components/Signup.jsx'

const mkEps = (count, price) =>
    Array.from({ length: count }, (_, i) => ({
        code:  `EP${String(i + 1).padStart(2, '0')}`,
        name:  `Episode ${i + 1}`,
        price: price,
    }))

const INITIAL_PRODUCTS = [
    { code: 'P01', name: 'Avatar 1',            price: '200.00', type: 'MOVIE',  genre: 'Sci-Fi',  description: '', totalEpisodes: 0,  episodes: [] },
    { code: 'P02', name: 'Avatar 2',            price: '200.00', type: 'MOVIE',  genre: 'Sci-Fi',  description: '', totalEpisodes: 0,  episodes: [] },
    { code: 'P03', name: 'Avatar 3',            price: '200.00', type: 'MOVIE',  genre: 'Sci-Fi',  description: '', totalEpisodes: 0,  episodes: [] },
    { code: 'P04', name: 'Star War',            price: '150.00', type: 'MOVIE',  genre: 'Sci-Fi',  description: '', totalEpisodes: 0,  episodes: [] },
    { code: 'P05', name: 'Your name',           price: '150.00', type: 'MOVIE',  genre: 'Romance', description: '', totalEpisodes: 0,  episodes: [] },
    { code: 'P06', name: 'Stranger Things ss1', price: '300.00', type: 'SERIES', genre: 'Horror',  description: 'A group of kids uncover a supernatural mystery in their small town.',  totalEpisodes: 8,  episodes: mkEps(8,  '37.50')  },
    { code: 'P07', name: 'Itaewon Class',       price: '450.00', type: 'SERIES', genre: 'Drama',   description: 'In a colorful Seoul neighborhood, an ex-con and his friends fight to make their street bar a reality.', totalEpisodes: 16, episodes: mkEps(16, '28.125') },
    { code: 'P08', name: 'One piece',           price: '450.00', type: 'SERIES', genre: 'Action',  description: 'A young pirate sets sail to find the legendary treasure called the One Piece.', totalEpisodes: 12, episodes: mkEps(12, '37.50')  },
    { code: 'P09', name: 'Blue Lock',           price: '200.00', type: 'SERIES', genre: 'Sports',  description: 'Three hundred strikers compete to become Japan\'s best striker.', totalEpisodes: 10, episodes: mkEps(10, '20.00')  },
]

const INITIAL_DATA = [
    { id: '0001', name: 'KIM MINJEONG', role: 'SUPER ADMIN', login: '12/12/24 01:03 PM', email: 'winrina@gmail.com', device: 'Mac',     ip: '203.0.113.1', last: '1 min ago',  risk: 'LOW',    time: 'MAR 23, 10:15', event: 'LOGIN' },
    { id: '0002', name: 'NUCH',         role: 'ADMIN',       login: '12/12/24 01:03 PM', email: 'winrina@gmail.com', device: 'Phone',   ip: '101.51.22.9', last: '5 min ago',  risk: 'HIGH',   time: 'MAR 23, 10:15', event: 'LOGIN' },
    { id: '0003', name: 'LISA',         role: 'ADMIN',       login: '12/12/24 01:03 PM', email: 'winrina@gmail.com', device: 'Windows', ip: '101.51.22.9', last: '1 min ago',  risk: 'MEDIUM', time: 'MAR 23, 10:15', event: 'LOGIN' },
    { id: '0004', name: 'JENNIE',       role: 'ADMIN',       login: '12/12/24 01:03 PM', email: 'winrina@gmail.com', device: 'Mac',     ip: '203.0.113.1', last: '2 days ago', risk: 'LOW',    time: 'MAR 23, 10:15', event: 'LOGIN' },
    { id: '0005', name: 'KARINA',       role: 'ADMIN',       login: '12/12/24 01:03 PM', email: 'winrina@gmail.com', device: 'Mac',     ip: '101.51.22.9', last: '1 min ago',  risk: 'LOW',    time: 'MAR 23, 10:15', event: 'LOGIN' },
    { id: '0006', name: 'NINGNING',     role: 'ADMIN',       login: '12/12/24 01:03 PM', email: 'winrina@gmail.com', device: 'Mac',     ip: '101.51.22.9', last: '5 min ago',  risk: 'MEDIUM', time: 'MAR 23, 10:15', event: 'LOGIN' },
]

function LoginRoute({ isLoggedIn, onLogin }) {
    const navigate = useNavigate()
    return isLoggedIn
        ? <Navigate to="/" replace />
        : <LoginPage onLogin={onLogin} onSignup={() => navigate('/signup')} />
}

function App() {
    const [isLoggedIn, setIsLoggedIn] = useState(false)
    const [username, setUsername]     = useState('LetmeuseKase')
    const [pic, setPic]               = useState(mockProfilePic)
    const [data, setData]             = useState(INITIAL_DATA)
    const [products, setProducts]     = useState(INITIAL_PRODUCTS)

    useEffect(() => {
        document.body.style.overflow = isLoggedIn ? '' : 'hidden'
    }, [isLoggedIn])

    const [signupUser, setSignupUser] = useState(() => {
        const saved = localStorage.getItem('user')
        return saved ? JSON.parse(saved) : null
    })
    const [signupList, setSignupList] = useState(() => {
        const saved = localStorage.getItem('signupList')
        return saved ? JSON.parse(saved) : []
    })

    const handleSignup = (formData) => {
        setSignupUser(formData)
        localStorage.setItem('user', JSON.stringify(formData))
        const newList = [...signupList, formData]
        setSignupList(newList)
        localStorage.setItem('signupList', JSON.stringify(newList))
    }

    const handleDelete = (id) => setData(prev => prev.filter(item => item.id !== id))

    const handleAddAdmin = (newAdmin) => {
        const nextId  = String(data.length + 1).padStart(4, '0')
        const now     = new Date()
        const dateStr = `${String(now.getMonth()+1).padStart(2,'0')}/${String(now.getDate()).padStart(2,'0')}/${String(now.getFullYear()).slice(-2)} ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')} ${now.getHours() >= 12 ? 'PM' : 'AM'}`
        const months  = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']
        const timeStr = `${months[now.getMonth()]} ${now.getDate()}, ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`
        setData(prev => [...prev, {
            id: nextId, name: newAdmin.fullname.toUpperCase(), role: newAdmin.role || 'ADMIN',
            login: dateStr, email: newAdmin.email, device: 'Mac', ip: '192.168.1.1',
            last: '1 min ago', risk: 'LOW', time: timeStr, event: 'LOGIN',
        }])
    }

    // Save entire product (fields + episodes)
    const handleSaveProduct = (updatedProduct) => {
        setProducts(prev => prev.map(p => p.code === updatedProduct.code ? updatedProduct : p))
    }

    const commonProps = { isLoggedIn, username, pic }

    return (
        <BrowserRouter>
            <Background />
            <Routes>
                <Route path="/login" element={<LoginRoute isLoggedIn={isLoggedIn} onLogin={() => setIsLoggedIn(true)} />} />
                <Route path="/signup" element={<Signup onSignup={handleSignup} onLoginSuccess={() => setIsLoggedIn(true)} />} />
                <Route path="/" element={isLoggedIn ? <LandingPage {...commonProps} /> : <Navigate to="/login" replace />} />
                <Route path="/products" element={isLoggedIn ? <ProductPage {...commonProps} data={products} /> : <Navigate to="/login" replace />} />
                <Route path="/products/edit/:code" element={isLoggedIn ? <ProductEditPage {...commonProps} products={products} onSave={handleSaveProduct} /> : <Navigate to="/login" replace />} />
                <Route path="/cast"      element={isLoggedIn ? <CastPage      {...commonProps} /> : <Navigate to="/login" replace />} />
                <Route path="/cast/edit/:code" element={isLoggedIn ? <CastEditPage {...commonProps} casts={products} onSave={handleSaveProduct} /> : <Navigate to="/login" replace />} />
                <Route path="/customers" element={isLoggedIn ? <CustomerPage  {...commonProps} /> : <Navigate to="/login" replace />} />
                <Route path="/admin-profile" element={isLoggedIn ? <AdminProfilePage {...commonProps} onSave={setUsername} /> : <Navigate to="/login" replace />} />
                <Route path="/management/*" element={isLoggedIn
                    ? <ManagementDashboard data={data} signupList={signupList} handleDelete={handleDelete} handleAddAdmin={handleAddAdmin} user={signupUser} pic={mockProfilePic} username="LetmeuseKase" />
                    : <Navigate to="/login" replace />
                } />
                <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
        </BrowserRouter>
    )
}

export default App